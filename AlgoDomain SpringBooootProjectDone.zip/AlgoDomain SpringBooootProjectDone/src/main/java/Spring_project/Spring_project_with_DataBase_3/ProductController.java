package Spring_project.Spring_project_with_DataBase_3;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ProductController {

	ArrayList<Product> al = new ArrayList<Product>();

	@Autowired
	SessionFactory sf;
	Product pp;

	@GetMapping("get Multiple Record ShowProduct List")
	public List multipleRecord2() {
		Session ss = sf.openSession();
		Criteria criteria = ss.createCriteria(Product.class);
		List<Product> ProductList = criteria.list();
		System.out.println(ProductList);
		return ProductList;
	}

	@GetMapping("One Record ShowProduct List/{id}")
	public Product getProduct(@PathVariable int id) {
		Session ss = sf.openSession();
		pp = ss.load(Product.class, id);
		System.out.println(pp);
		Product product = pp;
		for (Product Product : al) {
			if (Product.getProductID() == id) {
				product = Product;
			}
		}
		System.out.println("One Record Show Successfully Done... " + product);
		return product;
	}

	@PostMapping("insertProduct")
	Product addProduct(@RequestBody Product product) {
		Session ss = sf.openSession();
		Transaction tx = ss.beginTransaction();
		ss.save(product);
		System.out.println("Record Inserted Successfully Done... " + product);
		tx.commit();
		return product;
	}

	@PutMapping("updateProduct")
	Product updateFaculty(@RequestBody Product product) {
		Session ss = sf.openSession();
		Transaction tx = ss.beginTransaction();
		ss.update(product);
		System.out.println("Record Updated Successfully Done... " + product);
		tx.commit();
		return product;
	}

	@DeleteMapping("deleteProduct/{id}")
	public int deleteProduct(@PathVariable int id) {
		Session ss = sf.openSession();
		Transaction tx = ss.beginTransaction();
		pp = ss.load(Product.class, id);
		System.out.println(pp);
		ss.delete(pp);
		System.out.println("Record Deleted Successfully Done... " + id);
		tx.commit();
		return id;
	}

	@GetMapping("getProduct")
	public Product getProducts(@RequestBody Product product) {
		
		product.getProductPrice();
		
		return null;
	}

}
