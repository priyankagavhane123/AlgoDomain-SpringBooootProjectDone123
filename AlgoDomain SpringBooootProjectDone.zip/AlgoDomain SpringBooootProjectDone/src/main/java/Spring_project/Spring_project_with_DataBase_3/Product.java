package Spring_project.Spring_project_with_DataBase_3;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Product {

	@Id
	private int ProductID;
	private String ProductName;
	private String ProductType;
	private String ProductCategory;
	private	String ProductPrice;
	public Product() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Product(int productID, String productName, String productType, String productCategory, String productPrice) {
		super();
		ProductID = productID;
		ProductName = productName;
		ProductType = productType;
		ProductCategory = productCategory;
		ProductPrice = productPrice;
	}
	public int getProductID() {
		return ProductID;
	}
	public void setProductID(int productID) {
		ProductID = productID;
	}
	public String getProductName() {
		return ProductName;
	}
	public void setProductName(String productName) {
		ProductName = productName;
	}
	public String getProductType() {
		return ProductType;
	}
	public void setProductType(String productType) {
		ProductType = productType;
	}
	public String getProductCategory() {
		return ProductCategory;
	}
	public void setProductCategory(String productCategory) {
		ProductCategory = productCategory;
	}
	public String getProductPrice() {
		return ProductPrice;
	}
	public void setProductPrice(String productPrice) {
		ProductPrice = productPrice;
	}
	@Override
	public String toString() {
		return "Product [ProductID=" + ProductID + ", ProductName=" + ProductName + ", ProductType=" + ProductType
				+ ", ProductCategory=" + ProductCategory + ", ProductPrice=" + ProductPrice + "]";
	}
	
	
	
}
