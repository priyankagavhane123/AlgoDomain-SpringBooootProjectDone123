package Spring_project.Spring_project_with_DataBase_3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringProjectWithDataBase3Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringProjectWithDataBase3Application.class, args);
		System.err.println("Spring Database...");
	}

}
